import React from 'react';

function WithdrawalRestrictionManagementPanel() {
  return (
    <div className="card gradient-blue-purple lg:col-span-2">
      {/* Withdrawal restriction management content */}
    </div>
  );
}

export default WithdrawalRestrictionManagementPanel;
