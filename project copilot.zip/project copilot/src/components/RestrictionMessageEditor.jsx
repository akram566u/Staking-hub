import React, { useState } from 'react';

function RestrictionMessageEditor({ message, onSave, onCancel, onDelete }) {
  const [content, setContent] = useState(message.content);
  const [type, setType] = useState(message.type);

  return (
    <div className="p-4 border rounded bg-gray-800 mb-2">
      <div className="mb-2">
        <label className="block text-gray-100 text-sm font-bold mb-1">Type</label>
        <select
          className="input-field w-full py-2 px-3 text-base"
          value={type}
          onChange={e => setType(e.target.value)}
        >
          <option value="withdrawal">Withdrawal</option>
          <option value="deposit">Deposit</option>
        </select>
      </div>
      <div className="mb-2">
        <label className="block text-gray-100 text-sm font-bold mb-1">Message</label>
        <textarea
          className="input-field w-full py-2 px-3 text-base h-20"
          value={content}
          onChange={e => setContent(e.target.value)}
        />
      </div>
      <div className="flex space-x-2 mt-2">
        <button className="btn btn-primary flex-grow" onClick={() => onSave({ ...message, content, type })}>Save</button>
        <button className="btn btn-secondary flex-grow" onClick={onCancel}>Cancel</button>
        <button className="btn btn-secondary flex-grow bg-red-600 hover:bg-red-700" onClick={() => onDelete(message.id)}>Delete</button>
      </div>
    </div>
  );
}

export default RestrictionMessageEditor;
