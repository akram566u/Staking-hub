
import React from 'react';
import ThemeSelector from './ThemeSelector';

function WebsiteUISettingsPanel({ theme, onThemeChange, customThemes, onAddTheme, onEditTheme, onDeleteTheme }) {
  return (
    <div className="card gradient-indigo-fuchsia lg:col-span-2">
      <h3 className="text-xl font-semibold mb-4 text-purple-300">Website UI Settings</h3>
      <ThemeSelector
        value={theme}
        onChange={onThemeChange}
        allowAddTheme={true}
        customThemes={customThemes}
        onAddTheme={onAddTheme}
        onEditTheme={onEditTheme}
        onDeleteTheme={onDeleteTheme}
      />
    </div>
  );
}

export default WebsiteUISettingsPanel;
