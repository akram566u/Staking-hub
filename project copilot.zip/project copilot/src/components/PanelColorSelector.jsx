import React from 'react';

function PanelColorSelector({ value, onChange }) {
  return (
    <div className="space-y-2">
      <label className="block text-gray-100 text-base font-bold mb-2">Panel Background Color</label>
      <input
        type="color"
        className="w-12 h-8 border-2 border-gray-300 rounded"
        value={value}
        onChange={e => onChange(e.target.value)}
      />
    </div>
  );
}

export default PanelColorSelector;
