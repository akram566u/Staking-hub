
import React, { useEffect, useState } from 'react';

function RechargePanel({ restrictionMessages = [], getRestrictionCountdown }) {
  const [timer, setTimer] = useState('');
  useEffect(() => {
    if (!getRestrictionCountdown) return;
    const interval = setInterval(() => {
      setTimer(getRestrictionCountdown());
    }, 1000);
    return () => clearInterval(interval);
  }, [getRestrictionCountdown]);

  const restrictionMsg = restrictionMessages.find(m => m.type === 'deposit');

  return (
    <div className="card gradient-yellow-pink">
      {restrictionMsg && (
        <div className="mb-3 p-2 bg-yellow-900/60 rounded text-yellow-300 text-sm">
          {restrictionMsg.content}
          <div className="mt-1 text-xs text-yellow-200">{timer}</div>
        </div>
      )}
      {/* Recharge USDT panel content */}
    </div>
  );
}

export default RechargePanel;
