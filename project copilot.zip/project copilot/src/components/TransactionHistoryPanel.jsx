import React from 'react';

function TransactionHistoryPanel() {
  return (
    <div className="card gradient-orange-red">
      {/* Transaction history content */}
    </div>
  );
}

export default TransactionHistoryPanel;
