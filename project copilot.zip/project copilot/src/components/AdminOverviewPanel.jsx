import React from 'react';

function AdminOverviewPanel() {
  return (
    <div className="card gradient-blue-purple lg:col-span-2 mb-6">
      {/* Admin overview content */}
    </div>
  );
}

export default AdminOverviewPanel;
