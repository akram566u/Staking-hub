import React from 'react';

function Modal({ isOpen, onClose, message, children }) {
  if (!isOpen) return null;
  return (
    <div className="modal flex">
      <div className="modal-content glass-panel">
        <span className="modal-close-button" onClick={onClose}>&times;</span>
        <p className="text-lg font-semibold">{message}</p>
        <div className="mt-4 flex justify-center space-x-4">
          {children}
        </div>
      </div>
    </div>
  );
}

export default Modal;
