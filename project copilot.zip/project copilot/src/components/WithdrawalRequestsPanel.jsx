import React from 'react';

function WithdrawalRequestsPanel() {
  return (
    <div className="card gradient-orange-red lg:col-span-1">
      {/* Withdrawal requests content */}
    </div>
  );
}

export default WithdrawalRequestsPanel;
