import React from 'react';


// Accept customThemes as prop for admin extensibility
const defaultThemes = [
  { name: 'Abstract Crystal', value: 'abstract-crystal' },
  { name: 'Vibrant Sunset', value: 'vibrant-sunset' },
  { name: 'Deep Ocean', value: 'deep-ocean' },
  { name: 'Forest Mist', value: 'forest-mist' },
  { name: 'Solar Flare', value: 'solar-flare' },
  { name: 'Midnight Sky', value: 'midnight-sky' },
  { name: 'Emerald Dream', value: 'emerald-dream' },
  { name: 'Crimson Night', value: 'crimson-night' },
  { name: 'Lavender Haze', value: 'lavender-haze' },
];


function ThemeSelector({ value, onChange, allowAddTheme, customThemes = [], onAddTheme, onEditTheme, onDeleteTheme }) {
  const allThemes = [...defaultThemes, ...customThemes];

  const handleAddTheme = () => {
    const name = prompt('Enter new theme name:');
    if (!name) return;
    const value = name.toLowerCase().replace(/\s+/g, '-');
    if (allThemes.some(t => t.value === value)) {
      alert('Theme with this name already exists.');
      return;
    }
    if (onAddTheme) onAddTheme({ name, value });
  };

  const handleEditTheme = (theme) => {
    const newName = prompt('Edit theme name:', theme.name);
    if (!newName) return;
    if (onEditTheme) onEditTheme({ ...theme, name: newName });
  };

  const handleDeleteTheme = (theme) => {
    if (window.confirm(`Delete theme "${theme.name}"?`)) {
      if (onDeleteTheme) onDeleteTheme(theme.value);
    }
  };

  // Improved preview: try to match custom theme names to a color, fallback to gray
  const getThemePreview = (val) => {
    if (val.includes('sunset')) return 'linear-gradient(135deg, #FF8C00, #FF4500)';
    if (val.includes('crystal')) return 'radial-gradient(circle at center, #1a202c, #0f172a)';
    if (val.includes('ocean')) return 'linear-gradient(135deg, #0f2027, #2c5364)';
    if (val.includes('forest')) return 'linear-gradient(135deg, #56ab2f, #a8e063)';
    if (val.includes('solar')) return 'linear-gradient(135deg, #FFD700, #FF8C00)';
    if (val.includes('midnight')) return 'linear-gradient(135deg, #232526, #414345)';
    if (val.includes('emerald')) return 'linear-gradient(135deg, #348F50, #56B4D3)';
    if (val.includes('crimson')) return 'linear-gradient(135deg, #8B0000, #FF6347)';
    if (val.includes('lavender')) return 'linear-gradient(135deg, #b993d6, #8ca6db)';
    // Custom: try to use a color from the value
    if (/#[0-9a-fA-F]{6}/.test(val)) return val;
    return '#222';
  };

  return (
    <div className="space-y-2">
      <label className="block text-gray-100 text-base font-bold mb-2">Theme</label>
      <select
        className="input-field w-full py-2 px-3 text-base"
        value={value}
        onChange={e => onChange(e.target.value)}
      >
        {allThemes.map(theme => (
          <option key={theme.value} value={theme.value}>{theme.name}</option>
        ))}
      </select>
      {allowAddTheme && (
        <button className="btn btn-secondary mt-2" type="button" onClick={handleAddTheme}>Add New Theme</button>
      )}
      {/* List custom themes with edit/delete */}
      {allowAddTheme && customThemes.length > 0 && (
        <div className="mt-2">
          <div className="text-gray-300 text-xs mb-1">Custom Themes:</div>
          <ul className="space-y-1">
            {customThemes.map(theme => (
              <li key={theme.value} className="flex items-center space-x-2">
                <span className="flex-1">{theme.name}</span>
                <button className="text-blue-400 hover:underline text-xs" onClick={() => handleEditTheme(theme)}>Edit</button>
                <button className="text-red-400 hover:underline text-xs" onClick={() => handleDeleteTheme(theme)}>Delete</button>
              </li>
            ))}
          </ul>
        </div>
      )}
      {/* Theme preview swatch */}
      <div className="mt-2 flex items-center space-x-2">
        <span className="text-gray-300 text-sm">Preview:</span>
        <div className="w-8 h-8 rounded shadow" style={{ background: getThemePreview(value) }} />
      </div>
    </div>
  );
}

export default ThemeSelector;
