import React from 'react';

function InputField({ className = '', ...props }) {
  return (
    <input className={`input-field ${className}`} {...props} />
  );
}

export default InputField;
