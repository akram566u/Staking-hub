import React from 'react';

function UserDashboard() {
  return (
    <section className="w-full max-w-6xl glass-panel p-8 rounded-xl shadow-2xl grid grid-cols-1 md:grid-cols-3 gap-8 transition-opacity duration-500 ease-in-out custom-scrollbar overflow-y-auto max-h-[calc(100vh-160px)]">
      {/* User dashboard panels will go here */}
    </section>
  );
}

export default UserDashboard;
