import React from 'react';

function Header({ onSignIn, onSignUp, onSignOut, isSignedIn }) {
  return (
    <header className="glass-panel p-4 shadow-lg flex justify-between items-center z-10">
      <h1 className="text-3xl font-bold text-blue-400">Staking Hub</h1>
      <nav className="space-x-4">
        {!isSignedIn ? (
          <>
            <button onClick={onSignIn} className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors">Sign In</button>
            <button onClick={onSignUp} className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors">Sign Up</button>
          </>
        ) : (
          <button onClick={onSignOut} className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 transition-colors">Sign Out</button>
        )}
      </nav>
    </header>
  );
}

export default Header;
