import React from 'react';

function UserOverviewPanel() {
  return (
    <div className="card gradient-blue-purple">
      {/* User staking overview content */}
    </div>
  );
}

export default UserOverviewPanel;
