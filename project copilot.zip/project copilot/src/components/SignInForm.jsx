import React from 'react';

function SignInForm() {
  return (
    <section className="w-full max-w-md glass-panel p-8 rounded-xl shadow-2xl transition-opacity duration-500 ease-in-out">
      {/* Sign in form fields will go here */}
    </section>
  );
}

export default SignInForm;
