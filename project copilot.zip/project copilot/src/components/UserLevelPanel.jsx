import React from 'react';

function UserLevelPanel() {
  return (
    <div className="card gradient-green-cyan">
      {/* User staking level content */}
    </div>
  );
}

export default UserLevelPanel;
