import React from 'react';

function UserAdminContentPanel() {
  return (
    <div className="card gradient-yellow-pink">
      {/* Admin announcements & tasks for user */}
    </div>
  );
}

export default UserAdminContentPanel;
