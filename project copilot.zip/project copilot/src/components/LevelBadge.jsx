import React from 'react';

function LevelBadge({ level }) {
  return (
    <div className={`level-badge level-${level}`}>{level}</div>
  );
}

export default LevelBadge;
