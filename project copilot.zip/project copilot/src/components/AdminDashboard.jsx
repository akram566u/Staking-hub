
import React from 'react';
import RestrictionMessageManagementPanel from './RestrictionMessageManagementPanel';
import WebsiteUISettingsPanel from './WebsiteUISettingsPanel';
import StartScreenCustomizationPanel from './StartScreenCustomizationPanel';
import ManageUserWalletsPanel from './ManageUserWalletsPanel';

function AdminDashboard({
  restrictionMessages,
  onEditRestriction,
  onDeleteRestriction,
  onAddRestriction,
  theme,
  onThemeChange,
  customThemes,
  onAddTheme,
  onEditTheme,
  onDeleteTheme,
  userPanelColor,
  onPanelColorChange
}) {
  return (
    <section className="w-full max-w-6xl glass-panel p-8 rounded-xl shadow-2xl grid grid-cols-1 lg:grid-cols-2 gap-8 transition-opacity duration-500 ease-in-out custom-scrollbar overflow-y-auto max-h-[calc(100vh-160px)]">
      <RestrictionMessageManagementPanel
        restrictionMessages={restrictionMessages}
        onEdit={onEditRestriction}
        onDelete={onDeleteRestriction}
        onAdd={onAddRestriction}
      />
      <WebsiteUISettingsPanel
        theme={theme}
        onThemeChange={onThemeChange}
        customThemes={customThemes}
        onAddTheme={onAddTheme}
        onEditTheme={onEditTheme}
        onDeleteTheme={onDeleteTheme}
      />
      <StartScreenCustomizationPanel
        theme={theme}
        onThemeChange={onThemeChange}
        customThemes={customThemes}
        onAddTheme={onAddTheme}
        onEditTheme={onEditTheme}
        onDeleteTheme={onDeleteTheme}
        panelColor={userPanelColor}
        onPanelColorChange={onPanelColorChange}
      />
      <ManageUserWalletsPanel
        panelColor={userPanelColor}
        onPanelColorChange={onPanelColorChange}
      />
      {/* ...other admin panels as needed... */}
    </section>
  );
}

export default AdminDashboard;
