import React from 'react';

function DepositRequestsPanel() {
  return (
    <div className="card gradient-green-cyan lg:col-span-1">
      {/* Deposit requests content */}
    </div>
  );
}

export default DepositRequestsPanel;
