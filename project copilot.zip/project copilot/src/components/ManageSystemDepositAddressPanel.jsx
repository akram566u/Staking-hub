import React from 'react';

function ManageSystemDepositAddressPanel() {
  return (
    <div className="card gradient-indigo-fuchsia lg:col-span-2">
      {/* Manage system deposit address content */}
    </div>
  );
}

export default ManageSystemDepositAddressPanel;
