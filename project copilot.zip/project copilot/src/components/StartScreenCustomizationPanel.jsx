
import React from 'react';
import ThemeSelector from './ThemeSelector';
import PanelColorSelector from './PanelColorSelector';

function StartScreenCustomizationPanel({ theme, onThemeChange, customThemes, onAddTheme, onEditTheme, onDeleteTheme, panelColor, onPanelColorChange }) {
  return (
    <div className="card gradient-yellow-pink lg:col-span-2">
      <h3 className="text-xl font-semibold mb-4 text-purple-300">Start Screen Customization</h3>
      <ThemeSelector
        value={theme}
        onChange={onThemeChange}
        allowAddTheme={true}
        customThemes={customThemes}
        onAddTheme={onAddTheme}
        onEditTheme={onEditTheme}
        onDeleteTheme={onDeleteTheme}
      />
      <div className="mt-4">
        <PanelColorSelector value={panelColor} onChange={onPanelColorChange} />
      </div>
    </div>
  );
}

export default StartScreenCustomizationPanel;
