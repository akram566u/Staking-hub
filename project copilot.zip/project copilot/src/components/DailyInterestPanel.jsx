
import React, { useEffect, useState } from 'react';

function DailyInterestPanel({ userLevel = 1, userBalance = 0, interestTimer = 0 }) {
  const [timer, setTimer] = useState(interestTimer);
  useEffect(() => {
    setTimer(interestTimer);
    const interval = setInterval(() => {
      setTimer(t => t > 0 ? t - 1 : 0);
    }, 1000);
    return () => clearInterval(interval);
  }, [interestTimer]);

  const interestRates = [0, 0.018, 0.03, 0.05, 0.07, 0.09];
  const credited = userBalance * interestRates[userLevel];
  const hours = Math.floor(timer / 3600);
  const mins = Math.floor((timer % 3600) / 60);
  const secs = timer % 60;

  return (
    <div className="card gradient-orange-red">
      <h3 className="text-xl font-semibold mb-3 text-blue-300">Daily Interest Credit</h3>
      <p className="text-xl text-gray-100 mb-3">Next credit in:</p>
      <p className="text-5xl font-bold text-purple-400 text-center mb-2">{`${hours.toString().padStart(2, '0')}h ${mins.toString().padStart(2, '0')}m ${secs.toString().padStart(2, '0')}s`}</p>
      <p className="text-lg text-green-300 text-center">+{credited.toFixed(2)} USDT will be credited</p>
    </div>
  );
}

export default DailyInterestPanel;
