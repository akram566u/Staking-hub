import React from 'react';

function AdminLevelManagementPanel() {
  return (
    <div className="card gradient-yellow-pink lg:col-span-2">
      {/* Admin level management content */}
    </div>
  );
}

export default AdminLevelManagementPanel;
