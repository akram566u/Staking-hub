import React from 'react';

// Example placeholder for a reusable component
function GlassPanel({ children, className = '' }) {
  return (
    <div className={`glass-panel ${className}`}>
      {children}
    </div>
  );
}

export default GlassPanel;
