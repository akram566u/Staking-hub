import React from 'react';

function AnimatedBackground() {
  return <div className="animated-background" />;
}

export default AnimatedBackground;
