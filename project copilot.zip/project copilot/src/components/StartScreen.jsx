import React from 'react';

function StartScreen() {
  return (
    <section className="relative text-center transition-opacity duration-500 ease-in-out flex flex-col items-center justify-center overflow-hidden w-full h-full">
      {/* Three.js canvas and start screen content will go here */}
    </section>
  );
}

export default StartScreen;
