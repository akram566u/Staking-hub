
import React, { useState } from 'react';
import RestrictionMessageEditor from './RestrictionMessageEditor';

function RestrictionMessageManagementPanel({ restrictionMessages, onEdit, onDelete, onAdd }) {
  const [editingId, setEditingId] = useState(null);
  const [adding, setAdding] = useState(false);

  return (
    <div className="card gradient-orange-red lg:col-span-2">
      <h3 className="text-xl font-semibold mb-4 text-purple-300">Restriction Message Management</h3>
      <div className="space-y-4">
        {restrictionMessages.map(msg => (
          editingId === msg.id ? (
            <RestrictionMessageEditor
              key={msg.id}
              message={msg}
              onSave={m => { onEdit(msg.id, m); setEditingId(null); }}
              onCancel={() => setEditingId(null)}
              onDelete={onDelete}
            />
          ) : (
            <div key={msg.id} className="p-4 border rounded bg-gray-800 flex items-center justify-between">
              <div>
                <div className="font-bold text-yellow-300 text-sm mb-1">{msg.type.toUpperCase()}</div>
                <div className="text-gray-100 text-base">{msg.content}</div>
              </div>
              <div className="flex space-x-2">
                <button className="btn btn-primary py-1 px-3 text-xs" onClick={() => setEditingId(msg.id)}>Edit</button>
                <button className="btn btn-secondary py-1 px-3 text-xs" onClick={() => onDelete(msg.id)}>Delete</button>
              </div>
            </div>
          )
        ))}
        {adding && (
          <RestrictionMessageEditor
            message={{ id: null, type: 'withdrawal', content: '' }}
            onSave={m => { onAdd(m); setAdding(false); }}
            onCancel={() => setAdding(false)}
            onDelete={() => setAdding(false)}
          />
        )}
      </div>
      <button className="btn btn-primary mt-4" onClick={() => setAdding(true)}>Add New Restriction Message</button>
    </div>
  );
}

export default RestrictionMessageManagementPanel;
