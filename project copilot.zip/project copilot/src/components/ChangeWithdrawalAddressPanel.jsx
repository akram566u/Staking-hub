import React from 'react';

function ChangeWithdrawalAddressPanel() {
  return (
    <div className="card gradient-green-cyan">
      {/* Change withdrawal address content */}
    </div>
  );
}

export default ChangeWithdrawalAddressPanel;
