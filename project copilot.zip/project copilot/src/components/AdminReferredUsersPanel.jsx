import React from 'react';

function AdminReferredUsersPanel() {
  return (
    <div className="card gradient-yellow-pink lg:col-span-2">
      {/* Admin referred users content */}
    </div>
  );
}

export default AdminReferredUsersPanel;
