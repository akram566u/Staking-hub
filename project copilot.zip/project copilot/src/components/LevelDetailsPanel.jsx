import React from 'react';

function LevelDetailsPanel() {
  return (
    <div className="card gradient-indigo-fuchsia">
      {/* Staking level details content */}
    </div>
  );
}

export default LevelDetailsPanel;
