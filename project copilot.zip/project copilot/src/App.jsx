// This file will contain the main App component migrated from index.html.
// The structure, Tailwind classes, and logic will be ported from the provided HTML/JS.


import React, { useState, useEffect, useCallback } from 'react';
import Header from './components/Header';
import StartScreen from './components/StartScreen';
import SignUpForm from './components/SignUpForm';
import SignInForm from './components/SignInForm';
import UserDashboard from './components/UserDashboard';
import AdminDashboard from './components/AdminDashboard';
import Modal from './components/Modal';
import ThemeSelector from './components/ThemeSelector';

function App() {
  // --- State for authentication and UI ---
  const [user, setUser] = useState(null); // null = not signed in
  const [isAdmin, setIsAdmin] = useState(false);
  const [showSignIn, setShowSignIn] = useState(false);
  const [showSignUp, setShowSignUp] = useState(false);
  const [showStartScreen, setShowStartScreen] = useState(true);
  const [modal, setModal] = useState({ open: false, message: '', buttons: null });

  // --- Restriction Messages ---
  const [restrictionMessages, setRestrictionMessages] = useState([
    { id: 1, type: 'withdrawal', content: 'Withdrawals are locked for 45 days after your first deposit.' },
    { id: 2, type: 'deposit', content: 'Deposits require admin approval to reflect in your balance.' },
  ]);

  // --- Theme Management ---
  const [theme, setTheme] = useState('abstract-crystal');
  const [customThemes, setCustomThemes] = useState([]);

  // --- Panel Color Management ---
  const [userPanelColor, setUserPanelColor] = useState('#1a202c');

  // --- Daily Interest Timer ---
  const [lastInterestCredit, setLastInterestCredit] = useState(Date.now());
  const [interestTimer, setInterestTimer] = useState(24 * 60 * 60); // seconds

  // --- User Balance and Level (mock for now) ---
  const [userBalance, setUserBalance] = useState(1000);
  const [userLevel, setUserLevel] = useState(2); // 1-5

  // --- 45-day restriction timer (mock start date) ---
  const [restrictionStart, setRestrictionStart] = useState(Date.now() - 10 * 24 * 60 * 60 * 1000); // 10 days ago

  // --- Effects ---
  // Daily interest timer
  useEffect(() => {
    const interval = setInterval(() => {
      setInterestTimer(prev => {
        if (prev <= 1) {
          // Credit interest
          const interestRates = [0, 0.018, 0.03, 0.05, 0.07, 0.09];
          const credited = userBalance * interestRates[userLevel];
          setUserBalance(bal => bal + credited);
          setLastInterestCredit(Date.now());
          return 24 * 60 * 60;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [userBalance, userLevel]);

  // --- Restriction countdown ---
  const getRestrictionCountdown = useCallback(() => {
    const now = Date.now();
    const end = restrictionStart + 45 * 24 * 60 * 60 * 1000;
    const diff = end - now;
    if (diff <= 0) return 'Restriction lifted';
    const days = Math.floor(diff / (24 * 60 * 60 * 1000));
    const hours = Math.floor((diff % (24 * 60 * 60 * 1000)) / (60 * 60 * 1000));
    const mins = Math.floor((diff % (60 * 60 * 1000)) / (60 * 1000));
    const secs = Math.floor((diff % (60 * 1000)) / 1000);
    return `${days}d ${hours}h ${mins}m ${secs}s`;
  }, [restrictionStart]);

  // --- Restriction Message CRUD ---
  const handleEditRestriction = (id, newMsg) => {
    setRestrictionMessages(msgs => msgs.map(m => m.id === id ? { ...m, ...newMsg } : m));
  };
  const handleDeleteRestriction = id => {
    setRestrictionMessages(msgs => msgs.filter(m => m.id !== id));
  };
  const handleAddRestriction = msg => {
    setRestrictionMessages(msgs => [...msgs, { ...msg, id: Date.now() }]);
  };

  // --- Theme CRUD ---
  const handleAddTheme = themeObj => {
    setCustomThemes(t => [...t, themeObj]);
  };

  // --- Panel Color Change ---
  const handlePanelColorChange = color => setUserPanelColor(color);

  // --- UI Render ---
  return (
    <div className="bg-gray-900 text-gray-100 min-h-screen flex flex-col" style={{ background: userPanelColor }}>
      {/* Animated background, modals, header, main content, etc. */}
      <div className="animated-background"></div>
      <Header
        onSignIn={() => { setShowSignIn(true); setShowSignUp(false); setShowStartScreen(false); }}
        onSignUp={() => { setShowSignUp(true); setShowSignIn(false); setShowStartScreen(false); }}
        onSignOut={() => { setUser(null); setIsAdmin(false); setShowStartScreen(true); }}
        isSignedIn={!!user}
      />
      <main className="flex-grow flex items-center justify-center p-4">
        {showStartScreen && (
          <StartScreen
            theme={theme}
            onThemeChange={setTheme}
            onGetStarted={() => setShowStartScreen(false)}
          />
        )}
        {showSignIn && <SignInForm onSignIn={u => { setUser(u); setIsAdmin(u?.isAdmin); setShowSignIn(false); }} />}
        {showSignUp && <SignUpForm onSignUp={u => { setUser(u); setShowSignUp(false); }} />}
        {user && !isAdmin && (
          <UserDashboard
            restrictionMessages={restrictionMessages}
            getRestrictionCountdown={getRestrictionCountdown}
            userPanelColor={userPanelColor}
            userBalance={userBalance}
            userLevel={userLevel}
            interestTimer={interestTimer}
          />
        )}
        {user && isAdmin && (
          <AdminDashboard
            restrictionMessages={restrictionMessages}
            onEditRestriction={handleEditRestriction}
            onDeleteRestriction={handleDeleteRestriction}
            onAddRestriction={handleAddRestriction}
            theme={theme}
            onThemeChange={setTheme}
            customThemes={customThemes}
            onAddTheme={handleAddTheme}
            userPanelColor={userPanelColor}
            onPanelColorChange={handlePanelColorChange}
          />
        )}
      </main>
      <Modal isOpen={modal.open} onClose={() => setModal({ ...modal, open: false })} message={modal.message}>
        {modal.buttons}
      </Modal>
    </div>
  );
}

export default App;
