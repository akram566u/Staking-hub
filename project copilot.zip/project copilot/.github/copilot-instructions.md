<!-- Use this file to provide workspace-specific custom instructions to Copilot. For more details, visit https://code.visualstudio.com/docs/copilot/copilot-customization#_use-a-githubcopilotinstructionsmd-file -->

This is a React project created with Vite. Please use functional components, hooks, and Tailwind CSS. Migrate any custom JS from the original index.html into appropriate React components or hooks. Organize major UI sections into src/components.
